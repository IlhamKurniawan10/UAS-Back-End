### Have you take a look into our docs?
https://igorescobar.github.io/jQuery-Mask-Plugin/

### Want to contribute? Make sure you read this first
https://github.com/igorescobar/jQuery-Mask-Plugin#contributing

Is this plugin helping you out? Buy me a beer and cheers! :beer:

:bowtie: https://www.paypal.me/igorcescobar
